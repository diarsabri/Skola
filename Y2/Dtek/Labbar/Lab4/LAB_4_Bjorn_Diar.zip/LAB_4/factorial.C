#include <stdio.h>

int main()
{
    int a0 = 5;
    int a1 = a0-1;
    int a2 = 0;
    int a3 = 0;
    int v0 = 0;
    
    while(a1!=0){
        a2=a1;
        while(a2!=0){
            a3 = a3 + a0;
            a2--;
        }
        a0 = a3;
        a3 = 0;
        a1--;
    }
    v0=a0;

    printf("%d\n", a0);
}
